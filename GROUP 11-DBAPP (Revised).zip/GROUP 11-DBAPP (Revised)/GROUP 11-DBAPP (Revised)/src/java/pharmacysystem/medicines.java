package pharmacysystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class medicines {
    public int medicineID;
    public String generic_name;
    public String brand_name;
    public Double volume_ml;
    public Double dosage_mg;
    public int isPrescription;
    public String category;
    public Double sellingPrice;
    public String description;
    public int stock;
    public int supplier_id;
    public String supplier_name;
    
    public ArrayList<Integer> medicineIDList = new ArrayList<>();
    public ArrayList<String> generic_nameList = new ArrayList<>();
    public ArrayList<String> brand_nameList = new ArrayList<>();
    public ArrayList<Double> volume_mlList = new ArrayList<>();
    public ArrayList<Double> dosage_mgList = new ArrayList<>();
    public ArrayList<Integer> isPrescriptionList = new ArrayList<>();
    public ArrayList<String> categoryList = new ArrayList<>();
    public ArrayList<Double> sellingPriceList = new ArrayList<>();
    public ArrayList<String> descriptionList = new ArrayList<>();
    public ArrayList<Integer> supplier_idList = new ArrayList<>();
    
    private String database = "jdbc:mysql://localhost:3306/pharmacy_db?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false";
    
    public medicines() {
        
    }
    
    public void clear_array() {
        medicineIDList.clear();
        generic_nameList.clear();
        brand_nameList.clear();
        volume_mlList.clear();
        dosage_mgList.clear();
        isPrescriptionList.clear();
        categoryList.clear();
        sellingPriceList.clear();
        descriptionList.clear();
        supplier_idList.clear();
    }
    
    public void get_info(int id_no) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT medicine_id, generic_name, brand_name, volume_ml, dosage_mg, isPrescription, category, sellingPrice, description FROM medicine_info WHERE medicine_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, id_no);
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()) {
                medicineID = rst.getInt("medicine_id");
                generic_name = rst.getString("generic_name");
                brand_name = rst.getString("brand_name");
                volume_ml = rst.getDouble("volume_ml");
                if (rst.wasNull())
                    volume_ml = 0.0;
                
                dosage_mg = rst.getDouble("dosage_mg");
                if (rst.wasNull())
                    dosage_mg = 0.0;
                
                isPrescription = rst.getInt("isPrescription");
                category = rst.getString("category");
                sellingPrice = rst.getDouble("sellingPrice");
                description = rst.getString("description");
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void get_info_for_order(int id_no) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT m.medicine_id AS id, m.brand_name AS b_name, m.generic_name AS g_name, COUNT(ms.medicine_id) AS stock, m.supplierID AS s_id, m.sellingPrice as s_price FROM medicine_info m LEFT JOIN medicine_stock ms ON m.medicine_id = ms.medicine_id WHERE m.medicine_id = ? GROUP BY m.medicine_id ORDER BY m.medicine_id";
            String query2 = "SELECT supplierID, supp_name FROM supplier_info WHERE supplierID = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            PreparedStatement pstmt2 = conn.prepareStatement(query2);
            pstmt.setInt(1, id_no);
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()) {
                medicineID = rst.getInt("id");
                generic_name = rst.getString("g_name");
                brand_name = rst.getString("b_name");
                stock = rst.getInt("stock");
                sellingPrice = rst.getDouble("s_price");
                
                pstmt2.setInt(1, rst.getInt("s_id"));
                ResultSet rst2 = pstmt2.executeQuery();
                while (rst2.next()) {
                    supplier_id = rst2.getInt("supplierID");
                    supplier_name = rst2.getString("supp_name");
                }
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void get_all_meds() {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM medicine_info ORDER BY medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("medicine_id"));
                generic_nameList.add(rst.getString("generic_name"));
                brand_nameList.add(rst.getString("brand_name"));
                volume_mlList.add(rst.getDouble("volume_ml"));
                dosage_mgList.add(rst.getDouble("dosage_mg"));
                isPrescriptionList.add(rst.getInt("isPrescription"));
                categoryList.add(rst.getString("category"));
                sellingPriceList.add(rst.getDouble("sellingPrice"));
                descriptionList.add(rst.getString("description"));
                supplier_idList.add(rst.getInt("supplierID"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    
    public void get_meds_with_name(String name, int isPrescription) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT m.medicine_id AS id, COUNT(ms.medicine_id) AS stock FROM medicine_info m LEFT JOIN medicine_stock ms ON m.medicine_id = ms.medicine_id WHERE (m.brand_name LIKE ? OR m.generic_name LIKE ?) AND m.isPrescription = ? GROUP BY m.medicine_id HAVING stock >= 0 ORDER BY m.medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, name);
            pstmt.setInt(3, isPrescription);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("id"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void get_meds_with_category(String name) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT m.medicine_id AS id, COUNT(ms.medicine_id) AS stock FROM medicine_info m LEFT JOIN medicine_stock ms ON m.medicine_id = ms.medicine_id WHERE m.category = ? AND m.isPrescription = 0 GROUP BY m.medicine_id HAVING stock >= 0 ORDER BY m.medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("id"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void get_supplier_meds(String name) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT m.medicine_id AS id FROM medicine_info m RIGHT JOIN supplier_info s ON m.supplierID = s.supplierID WHERE s.supp_name = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("id"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void get_low_meds() {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT m.medicine_id AS id, COUNT(ms.medicine_id) AS stock FROM medicine_info m LEFT JOIN medicine_stock ms ON m.medicine_id = ms.medicine_id GROUP BY m.medicine_id HAVING stock <= 10 ORDER BY m.medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("id"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public void get_category() {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT DISTINCT category FROM medicine_info ORDER BY category";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                categoryList.add(rst.getString("category"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public int check_if_medID_exists(int id_no) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT medicine_id FROM medicine_info WHERE medicine_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, id_no);
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()) {
                if (rst.getInt("medicine_id") == id_no)
                    return 1;
            }
            pstmt.close();
            conn.close();
            
            return 0;
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int addMedicine() {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "INSERT INTO medicine_info (generic_name, brand_name, volume_ml, dosage_mg, isPrescription, category, sellingPrice, description, supplierID) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, generic_name);
            pstmt.setString(2, brand_name);
            pstmt.setDouble(3, volume_ml);
            pstmt.setDouble(4, dosage_mg);
            pstmt.setInt(5, isPrescription);
            pstmt.setString(6, category);
            pstmt.setDouble(7, sellingPrice);
            pstmt.setString(8, description);
            pstmt.setInt(9, supplier_id);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int updateMedicine(String field, int medicineID) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query;
            PreparedStatement pstmt;
            if (field.equals("generic_name")) {
                query = "UPDATE medicine_info SET generic_name = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, generic_name);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("brand_name")) {
                query = "UPDATE medicine_info SET brand_name = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, brand_name);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("volume_in_ml")) {
                query = "UPDATE medicine_info SET volume_ml = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setDouble(1, volume_ml);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("dosage_in_mg")) {
                query = "UPDATE medicine_info SET dosage_mg = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setDouble(1, dosage_mg);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("prescription")) {
                query = "UPDATE medicine_info SET isPrescription = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, isPrescription);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("category")) {
                query = "UPDATE medicine_info SET category = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, category);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("selling_price")) {
                query = "UPDATE medicine_info SET sellingPrice = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setDouble(1, sellingPrice);
                pstmt.setInt(2, medicineID);

            } else if (field.equals("description")) {
                query = "UPDATE medicine_info SET description = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, description);
                pstmt.setInt(2, medicineID);

            } else {
                query = "UPDATE medicine_info SET supplierID = ? WHERE medicine_id = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setInt(1, supplier_id);
                pstmt.setInt(2, medicineID);

            }

            
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public void searchMedicineByName(String name) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM medicine_info WHERE brand_name LIKE ? OR generic_name LIKE ? ORDER BY medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, name);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("medicine_id"));
                generic_nameList.add(rst.getString("generic_name"));
                brand_nameList.add(rst.getString("brand_name"));
                volume_mlList.add(rst.getDouble("volume_ml"));
                dosage_mgList.add(rst.getDouble("dosage_mg"));
                isPrescriptionList.add(rst.getInt("isPrescription"));
                categoryList.add(rst.getString("category"));
                sellingPriceList.add(rst.getDouble("sellingPrice"));
                descriptionList.add(rst.getString("description"));
                supplier_idList.add(rst.getInt("supplierID"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    } 

    public void searchMedicineByCategory(String category) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM medicine_info WHERE category = ? ORDER BY medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, category);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("medicine_id"));
                generic_nameList.add(rst.getString("generic_name"));
                brand_nameList.add(rst.getString("brand_name"));
                volume_mlList.add(rst.getDouble("volume_ml"));
                dosage_mgList.add(rst.getDouble("dosage_mg"));
                isPrescriptionList.add(rst.getInt("isPrescription"));
                categoryList.add(rst.getString("category"));
                sellingPriceList.add(rst.getDouble("sellingPrice"));
                descriptionList.add(rst.getString("description"));
                supplier_idList.add(rst.getInt("supplierID"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void searchMedicineByPrescription(int isPrescription) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM medicine_info WHERE isPrescription = ? ORDER BY medicine_id";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, isPrescription);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                medicineIDList.add(rst.getInt("medicine_id"));
                generic_nameList.add(rst.getString("generic_name"));
                brand_nameList.add(rst.getString("brand_name"));
                volume_mlList.add(rst.getDouble("volume_ml"));
                dosage_mgList.add(rst.getDouble("dosage_mg"));
                isPrescriptionList.add(rst.getInt("isPrescription"));
                categoryList.add(rst.getString("category"));
                sellingPriceList.add(rst.getDouble("sellingPrice"));
                descriptionList.add(rst.getString("description"));
                supplier_idList.add(rst.getInt("supplierID"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public static void main(String[] args){
        medicines med = new medicines();
        med.generic_name = "Maybe";
        med.brand_name = "Hey dude";
        med.volume_ml = 12.1;
        System.out.println(med.updateMedicine("volume_ml", 20));
    }
}

