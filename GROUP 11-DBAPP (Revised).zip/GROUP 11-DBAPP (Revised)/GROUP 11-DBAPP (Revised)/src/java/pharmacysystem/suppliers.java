package pharmacysystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

public class suppliers {
    public int supplierID;
    public String name;
    public String description;
    public String address;
    public Long contact_number;
    
    public ArrayList<Integer> supplierIDList = new ArrayList<>();
    public ArrayList<String> nameList = new ArrayList<>();
    public ArrayList<String> descriptionList = new ArrayList<>();
    public ArrayList<String> addressList = new ArrayList<>();
    public ArrayList<Long> contact_numberList = new ArrayList<>();
    
    private String database = "jdbc:mysql://localhost:3306/pharmacy_db?user=root&password=12345678&useTimezone=true&serverTimezone=UTC&useSSL=false";
    
    public suppliers() {
        
    }
    
    public void clear_array() {
        supplierIDList.clear();
        nameList.clear();
        descriptionList.clear();
        contact_numberList.clear();
    }

    public void get_info(int supplierID) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM supplier_info WHERE supplierID = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, supplierID);
            ResultSet rst = pstmt.executeQuery();

            while (rst.next()) {
                this.supplierID = rst.getInt("supplierID");
                this.name = rst.getString("supp_name");
                this.description = rst.getString("supp_description");
                this.address = rst.getString("address");
                this.contact_number = rst.getLong("contact_number");
            }
            
            pstmt.close();
            conn.close();

        } catch (Exception e) {
            System.out.println(e.getMessage());

        }
    }
    
    public void get_supplier_names() {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT supp_name FROM supplier_info ORDER BY supp_name";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rst = pstmt.executeQuery();
            clear_array();
            while (rst.next()) {
                nameList.add(rst.getString("supp_name"));
            }
            pstmt.close();
            conn.close();
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    public int check_if_supplierID_exists(int id_no) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT supplierID FROM supplier_info WHERE supplierID = ?";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, id_no);
            ResultSet rst = pstmt.executeQuery();
            while (rst.next()) {
                if (rst.getInt("supplierID") == id_no)
                    return 1;
            }
            pstmt.close();
            conn.close();
            
            return 0;
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int addSupplier() {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query = "INSERT INTO supplier_info (supp_name, supp_description, address, contact_number) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setString(3, address);
            pstmt.setLong(4, contact_number);
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int deleteSupplier(int supplierID) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query1 = "DELETE FROM supplier_info WHERE supplierID = ?";
            String query2 = "UPDATE orders SET supplierID = NULL WHERE supplierID = ?";
            String query3 = "UPDATE medicine_info SET supplierID = NULL WHERE supplierID = ?";
            PreparedStatement pstmt1 = conn.prepareStatement(query1);
            PreparedStatement pstmt2 = conn.prepareStatement(query2);
            PreparedStatement pstmt3 = conn.prepareStatement(query3);
            
            pstmt1.setInt(1, supplierID);
            pstmt2.setInt(1, supplierID);
            pstmt3.setInt(1, supplierID);

            pstmt1.executeUpdate();
            pstmt2.executeUpdate();
            pstmt3.executeUpdate();

            pstmt1.close();
            pstmt2.close();
            pstmt3.close();

            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int updateSupplier(String field, int supplierID) {
        try {
            Connection conn = DriverManager.getConnection(database);
            String query;
            PreparedStatement pstmt;
            if (field.equals("name")) {
                query = "UPDATE supplier_info SET supp_name = ? WHERE supplierID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, name);
                pstmt.setInt(2, supplierID);

            } else if (field.equals("description")) {
                query = "UPDATE supplier_info SET supp_description = ? WHERE supplierID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, description);
                pstmt.setInt(2, supplierID);

            } else if (field.equals("address")) {
                query = "UPDATE supplier_info SET address = ? WHERE supplierID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setString(1, address);
                pstmt.setInt(2, supplierID);
                
            } else {
                query = "UPDATE supplier_info SET contact_number = ? WHERE supplierID = ?";
                pstmt = conn.prepareStatement(query);
                pstmt.setLong(1, contact_number);
                pstmt.setInt(2, supplierID);
            }
            pstmt.executeUpdate();
            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int searchSupplierByName(String name) {
        try {
            clear_array();

            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM supplier_info WHERE supp_name LIKE ? ORDER BY supplierID";
            PreparedStatement pstmt = conn.prepareStatement(query);
            pstmt.setString(1, "%" + name + "%");
            ResultSet rst = pstmt.executeQuery();
            
            while (rst.next()) {
                this.supplierID = rst.getInt("supplierID");
                this.name = rst.getString("supp_name");
                this.description = rst.getString("supp_description");
                this.address = rst.getString("address");
                this.contact_number = rst.getLong("contact_number");

                supplierIDList.add(this.supplierID);
                nameList.add(this.name);
                descriptionList.add(this.description);
                addressList.add(this.address);
                contact_numberList.add(this.contact_number);
            }

            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }

    public int getAllSuppliers() {
        try {
            clear_array();

            Connection conn = DriverManager.getConnection(database);
            String query = "SELECT * FROM supplier_info ORDER BY supplierID";
            PreparedStatement pstmt = conn.prepareStatement(query);
            ResultSet rst = pstmt.executeQuery();
            
            while (rst.next()) {
                supplierID = rst.getInt("supplierID");
                name = rst.getString("supp_name");
                description = rst.getString("supp_description");
                contact_number = rst.getLong("contact_number");

                supplierIDList.add(supplierID);
                nameList.add(name);
                descriptionList.add(description);
                contact_numberList.add(contact_number);
            }

            pstmt.close();
            conn.close();
            return 1;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return 0;
        }
    }
    
    public static void main(String[] args){
        suppliers s = new suppliers();
        s.name = "alonzo";
        s.description = "this is a test";
        s.address = "sfclu";
        s.contact_number = 9063296567L;
        s.addSupplier();
    }
}
